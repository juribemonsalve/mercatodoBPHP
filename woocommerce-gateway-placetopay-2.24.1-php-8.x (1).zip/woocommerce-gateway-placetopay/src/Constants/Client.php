<?php

namespace PlacetoPay\PaymentMethod\Constants;

interface Client
{
    public const GNT = 'Trgarg';
    public const GOU = 'TBH';
    public const PTP = 'Cynprgbcnl';
}